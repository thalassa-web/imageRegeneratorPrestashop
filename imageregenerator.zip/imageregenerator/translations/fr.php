<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{imageregenerator}prestashop>imageregenerator_c58f4c5e1cdd88526615717f9ddc3941'] = 'Régénaration des images en ajax.';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_876f23178c29dc2552c0b48bf23cd9bd'] = 'Vous-vous vraiment désinstaller ?';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_0f40e8817b005044250943f57a21c5e7'] = 'Aucun nom fourni';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_b2326c3a3498ee50c8120fbaede6eeed'] = 'Régénérer';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_505a83f220c02df2f85c3810cd9ceb38'] = 'Réussi';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Erreur';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_8f3d10eb21bd36347c258679eba9e92b'] = 'Terminé';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_7ecb9cb385193e0550952a04926b0812'] = 'File d\'attente enregistrée';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_4e28bae184604899eb5fc77d97f07f71'] = 'File d\'attente effacée';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_33323dbad01006edfbadcb5396ab56a8'] = 'Vous pouvez regénérer vos images en toute sécurité.';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_790eac10f2d9e840d56209bdafc51b84'] = 'C\'est parti';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_bac2aec3ee8d7d495123dbe5ca2fdac9'] = 'REPRENDRE';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_b5859d8721cfdc0312b2838b9c985bc1'] = 'RÉINITIALISER';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_8998e0db5017978a3b718c74acc38387'] = 'Watermark ? (le module watermark doit être activé)';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_da33783082da9e81b313a3530be04d3a'] = 'Fichier source non trouvé ou vide (%s)';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_75b1aa036d2631c1da9f21c5390162e7'] = 'L\'image originale (%s) semble corrompue ou problème de permission sur le dossier';
$_MODULE['<{imageregenerator}prestashop>imageregenerator_23cc1d02331de31fa752c866444f5e2b'] = 'Image orginale non trouvée ou vide (%s)';

